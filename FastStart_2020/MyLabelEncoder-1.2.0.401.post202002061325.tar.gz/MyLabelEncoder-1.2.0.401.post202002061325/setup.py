import setuptools
from setuptools import find_packages
from distutils.core import setup
import datetime
VERSION='1.2.0.401-' + datetime.datetime.now().strftime("%Y%m%d%H%M")
setup(
    name='MyLabelEncoder',
    version=VERSION,
    packages=['.'],
    author='IBM',
    author_email='mingun@ibm.com',
    license='IBM',
    description='Customized categorical label encoder'
)
