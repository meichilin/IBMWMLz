from sklearn.preprocessing import LabelEncoder

class MyLabelEncoder:
    def __init__(self, cols=None):
        self.cols = cols
        self.le_list = [LabelEncoder() for _ in range(len(self.cols))]

    def fit(self, X, y=None):
        for i, col in enumerate(self.cols):
            self.le_list[i].fit(X[col])
        return self

    def transform(self, X):
        output = X.copy()
        for i, col in enumerate(self.cols):
            output[col] = self.le_list[i].transform(output[col])
        return output