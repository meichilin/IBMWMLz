import setuptools
from setuptools import find_packages
from distutils.core import setup
import datetime
VERSION='1.2.0.401-' + datetime.datetime.now().strftime("%Y%m%d%H%M")
setup(
    name='MyLabelEncoder',
    version=VERSION,
#    packages=find_packages(),
    packages=['.'],
    author='IBM',
    author_email='cdl@cn.ibm.com',
    license='IBM',
    description='for wm'
)
